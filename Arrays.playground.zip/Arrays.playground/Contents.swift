//: Playground - noun: a place where people can play

import UIKit

var numbers = [1,2,3,4]
var letters = ["a","b","c"]

numbers[0]
numbers[1]
numbers[2]
numbers[3]

letters[2]
letters[1]
letters[0]

var groceryList = ["eggs", "milk", "cat food"]

groceryList.append("arugula")
groceryList += ["cheese", "crackers"]

groceryList.remove(at: 4)

for index in 0...(groceryList.count - 1) {
    print(groceryList[index])
}

var otherList = [String]()

if( !otherList.isEmpty) {
    print(otherList.last!)
}

//arrayAll has 1 ... 100
//arrayEven has only even numbers from 1 ... 100

var arrayAll = [Int] ()
var arrayEven = [Int] ()

for index in 1 ... 100 {
    arrayAll += [index]
    if (index % 2 == 0) {
        arrayEven += [index]
    }
}

print(arrayAll)
print(arrayEven)
