//: Playground - noun: a place where people can play

import UIKit

// Fizz Buzz game
// Fizz = divisible by 3
// Buzz = divisible by 5


    
func checkValue(index: Int) -> String {
    var valueToReturn: String = ""
    
    if( index % 3 == 0 && index % 5 == 0){
        valueToReturn = "FizzBuzz"
    }
    else if(index % 3 == 0){
        valueToReturn = "Fizz"
    }
    else if(index % 5 == 0) {
        valueToReturn = "Buzz"
        }
    else {
        valueToReturn = String(index)
    }
    return valueToReturn
}

for counter in 1...100 {
    print(checkValue(index: counter))

}