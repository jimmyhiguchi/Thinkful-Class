//: Playground - noun: a place where people can play

import UIKit

print("Hello World")



let name = "Peter"
let sex = "male"
let location = "New York"

var weight = 180.5
var milesRunToday: Double = 3
var numberOfPushups = 50

var exercisedToday = true

milesRunToday = 3.4

