//: Playground - noun: a place where people can play

import UIKit

// Where are the now app
//Thomas	Casper College
//Laura     Casper College
//Grae      Casper College
//Ben       Harvard
//Liz       WyoTech
//Bhaumik	WyoTech
//Sam       WyoTech
//Tatiana	WyoTech
//Nora      WyoTech
//Saul      WyoTech

var studentName = "Nora"

if (studentName == "Thomas") {
    print("\(studentName) is at Casper College")
}
else if (studentName == "Laura") {
    print("\(studentName) is at Casper College")
}
else {
    print("\(studentName)? Who is \(studentName)?")
}

switch studentName {
    case "Thomas", "Laura", "Grae":
        print("\(studentName) is at Casper College")
    case "Ben":
        print("\(studentName) is at Harvard")
    case "Liz", "Bhaumik", "Sam", "Tatiana", "Nora", "Saul":
        print("\(studentName) is at Wyotech")
    default:
        print("\(studentName)? Who is \(studentName)?")
}

var letter = "u"

switch letter {
    case "b","c","d","f","g","h","j","k","l","m","n","p","q","r","s","t","v","w","x","y","z":
        print("it's a consonent")
    case "a","e","i","o","u":
        print("it's a vowel")
    default:
        print("i don't know what that is")
    
}

