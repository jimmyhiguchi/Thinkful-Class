//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var name = "Peter"
var gender = "male"
var profession =  "Software Developer"
var location = "New York City"

var name2 = "Amy"
var gender2 = "female"
var profession2 = "Professor"
var location2 = "San Francisco"

class Person {
    var name: String
    var gender: String = "unknown"
    var profession: String = "unknown"
    var location: String
    var age: Int
    var partner: Person?
    
    
    init(name: String, gender: String, profession: String, location: String, age: Int) {
        self.name = name
        self.gender = gender
        self.profession = profession
        self.location = location
        self.age = age
    }
    
    func createRelationship(partner: Person) {
        self.partner = partner
    }
    func displayRelationshipMessage() {
        if let partner = partner {
            print("\(name) is in a relationship with \(partner.name)")
        }
    }
    
}

let peter = Person(name: "Peter", gender: "male", profession: "Software Developer", location: "New York", age: 40)

let amy = Person(name: "Amy", gender: "female", profession: "Professor", location: "San Francisco", age: 37)

let jimmy = Person(name: "Jimmy", gender: "male", profession: "driver", location: "Alameda", age: amy.age + 13)


class Person2 {
    var name: String = "unknown"
    var gender: String = "unknown"
    var profession: String = "unknown"
    var location: String = "unknown"
    var age: Int = 0
    
}


let winnie = Person2()

winnie.name = "Winnie"
winnie.gender = "female"
winnie.profession = "Master Planner"
winnie.location = "Alameda"

// are you in a relationship added

peter.createRelationship(partner: amy)





    

