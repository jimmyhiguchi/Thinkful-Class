//: Playground - noun: a place where people can play

import UIKit


// superclass shape

class Shape {
    var color: UIColor
    
    init(color: UIColor) {
        self.color = color
    }
    
    func getArea() -> Double {
        
        return 0
    }

}

// Class: Superclass

class Circle: Shape {
    
    var radius: Int
    
    init(radius: Int, color: UIColor) {
        self.radius = radius
        super.init(color: color)
    }
    override func getArea() -> Double {
        return Double.pi * Double(radius * radius)
    }
    
    
}

class Square: Shape {
    
    var width: Int
    
    init(width: Int, color: UIColor) {
        self.width = width
        super.init(color: color)
    }
    
    override func getArea() -> Double {
        return Double(width * width)
    }

}

class Rectangle: Shape {
    
    var width: Int
    var length: Int
    
    init(width: Int, length: Int, color: UIColor) {
        self.width = width
        self.length = length
        super.init(color: color)
    }
    
    override func getArea() -> Double {
        return Double(width * length)
    }
}

var circle = Circle(radius: 50, color: UIColor.blue)
circle.color
circle.radius

circle.getArea()

var square = Square(width: 100, color: UIColor.red)
square.color
square.width

square.getArea()

var rectangle = Rectangle(width: 10, length: 5, color: UIColor.green)
rectangle.color
rectangle.width
rectangle.length

rectangle.getArea()

class Music {
    var genre: String
    var artist: String
    
    init(genre: String, artist: String) {
        self.genre = genre
        self.artist = artist
    }
    
}

class Vinyl: Music {
    var format: String
    
    init(format: String, genre: String, artist: String) {
        self.format = format
        super.init(genre: genre, artist: artist)
       
    }
}

class Cassette: Music {
    var format: String
    
    init(format: String, genre: String, artist: String) {
        self.format = format
        super.init(genre: genre, artist: artist)
    }
}

class Cd: Music {
    var format: String
    
    init(format: String, genre: String, artist: String) {
        self.format = format
        super.init(genre: genre, artist: artist)
    }
}


let coltrane = Vinyl(format: "LP", genre: "Jazz", artist: "John Coltrane")

let maggotBrain = Cassette(format: "Full length", genre: "Funk", artist: "Funkadelic")

let operationDoomsday = Cd(format: "Single", genre: "Rap", artist: "MF Doom")

operationDoomsday.format = "Full length"

let syntheticSubstitution = Vinyl(format: "7 inch single", genre: "R&B", artist: "Melvin Bliss")

// structures aka struct

let point = CGPoint(x: 0, y: 0)
let size = CGSize(width: 320, height: 320)

let rect = CGRect(origin: point, size: size)

CGRect(x: 100, y: 10, width: 300, height: 200)


