//: Playground - noun: a place where people can play

import UIKit

// Population of Swiftlandia over 100 years at a constant 0.7% per year
// starting with population 100,000 people

var population: Double = 100000

print(Int(population))

for year in 1...100 {
    population = population * 1.007
    print(Int(population))
}

