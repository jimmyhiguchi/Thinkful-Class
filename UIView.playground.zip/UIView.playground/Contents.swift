//: Playground - noun: a place where people can play

import UIKit

// example of UIView

let view = UIView(frame: CGRect(x: 0, y: 0, width: 320, height: 320))

view.backgroundColor = UIColor.yellow

let redView = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 100 ))

redView.backgroundColor = UIColor.red

view.addSubview(redView)

// Visual Shapes

class Shape: UIView {
    var color: UIColor
    
    init(color: UIColor) {
        self.color = color
        super.init(frame: CGRect.zero) //?
        self.backgroundColor = color //?
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented") //?
    }
    
    func getArea() -> Double {
        return 0
    }
}


class Square: Shape {
    var width: Int
    
    init(width: Int, color: UIColor) {
        self.width = width
        super.init(color: color) //?
        self.frame.size = CGSize(width: width, height: width) // ?
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func getArea() -> Double {
        return Double(width * width)
    }
    
    
    
}

class Circle: Shape {
    var radius: Int
    
    init(radius: Int, color: UIColor) {
        self.radius = radius
        super.init(color: color)
        self.frame.size = CGSize(width: 2 * radius, height: 2 * radius)
        self.layer.cornerRadius = CGFloat(radius)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func getArea() -> Double {
        return Double.pi * Double(radius * radius)
    }
}

class Rectange: Shape {
    var width: Int
    var height: Int
    
    init(width: Int, height: Int, color: UIColor) {
        self.width = width
        self.height = height
        super.init(color: color)
        self.frame.size = CGSize(width: width, height: height)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
        override func getArea() -> Double {
            return Double(width * height)
        }
}

class RoundedRectangle: Shape {
    var width: Int
    var height: Int
    
    init(width: Int, height: Int, color: UIColor) {
        self.width = width
        self.height = height
        super.init(color: color)
        self.frame.size = CGSize(width: width, height: height)
        self.layer.cornerRadius = CGFloat(height/2)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func getArea() -> Double {
        return Double(width * height)
    }
}

var circle = Circle(radius: 100, color: UIColor.red)
var square = Square(width: 50, color: UIColor.blue)
var rectangle = Rectange(width: 150, height: 75, color: UIColor.green)
var oval = RoundedRectangle(width: 90, height: 45, color: UIColor.white)

let newView = UIView(frame: CGRect(x: 0, y: 0, width: 320, height: 320))

circle.center = CGPoint(x: 100, y: 100)
square.center = CGPoint(x: 200, y: 200)
rectangle.center = CGPoint(x: 50, y: 0)
oval.center = CGPoint(x: 250, y: 50)


newView.addSubview(circle)
newView.addSubview(square)
newView.addSubview(rectangle)
newView.addSubview(oval)


newView





